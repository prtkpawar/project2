
def lambda_handler(event,context):
    print('hello :pratik')
